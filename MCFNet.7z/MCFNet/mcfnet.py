import torch
from torch import nn
import torch.nn.functional as F
from itertools import chain
from torchvision.models import resnet50


def convblock(in_, out_, ks, st, pad):
    return nn.Sequential(
        nn.Conv2d(in_, out_, ks, st, pad),
        nn.BatchNorm2d(out_),
        nn.ReLU(inplace=True)
    )


class MRM(nn.Module):
    def __init__(self, in_ch):
        super(MRM, self).__init__()

        self.feature = nn.Sequential(
            nn.Conv2d(in_ch + in_ch, in_ch // 4, 3, 1, 1 ),
            nn.BatchNorm2d(in_ch // 4),
            nn.PReLU(),
            nn.Conv2d(in_ch // 4, 2, 3, 1, 1)
        )

    def forward(self, in_rgb, in_t):
        
        rgbt = torch.matmul(in_rgb, in_t)
        rgb = in_rgb - rgbt
        t = in_t - rgbt

        G = self.feature(torch.cat((rgb, t), 1))
        G = F.adaptive_avg_pool2d(G, 1)
        G = F.softmax(G, 1)

        return G


class QM(nn.Module):
    def __init__(self, ch_1, ch_2):  # ch_1:previous, ch_2:current/output
        super(QM, self).__init__()
        self.ca1 = CA(ch_1)
        self.ch2 = ch_2
        self.spm = SCAM(ch_2)
        self.gate = MRM(ch_2)
        self.cur = convblock(ch_2, 128, 3, 1, 1)
        self.conv_pre = convblock(ch_1, ch_2, 3, 1, 1)

        self.conv_fuse = nn.Sequential(
            nn.Conv2d(ch_2, ch_2 // 4, 3, 1, 1),
            nn.BatchNorm2d(ch_2 // 4),
            nn.ReLU(),
            nn.Conv2d(ch_2 // 4, ch_2, 3, 1, 1),
            nn.BatchNorm2d(ch_2),
            nn.ReLU()
        )

    def forward(self, e_r, e_t, pre):
        cur_size = e_r.size()[2:]
        ch_2 = self.ch2

        g = self.gate(e_r, e_t)

        e_r = g[:, 0, :, :].unsqueeze(1).repeat(1, ch_2, 1, 1) * e_r
        e_t = g[:, 1, :, :].unsqueeze(1).repeat(1, ch_2, 1, 1) * e_t

        mask = self.spm(e_r, e_t)
        # print(mask.shape)
        mask = F.interpolate(mask, cur_size, mode='bilinear', align_corners=True)
        e_r = mask * e_r
        e_t = (1 - mask) * e_t

        pre = self.ca1(pre)
        pre = self.conv_pre(F.interpolate(pre, cur_size, mode='bilinear', align_corners=True))

        fus = pre + e_r + e_t
        fus = pre + self.conv_fuse(fus)
        return fus


class QM5(nn.Module):
    def __init__(self, ch_1, ch_2):  # ch_1:previous, ch_2:current/output
        super(QM5, self).__init__()
        self.ca1 = CA(ch_1)
        self.ch2 = ch_2
        self.spm = SCAM(ch_2)
        self.gate = MRM(ch_2)
        self.conv_pre = convblock(ch_1, ch_2, 3, 1, 1)

        self.conv_fuse = nn.Sequential(
            nn.Conv2d(ch_2, ch_2 // 4, 3, 1, 1),
            nn.BatchNorm2d(ch_2 // 4),
            nn.ReLU(),
            nn.Conv2d(ch_2 // 4, ch_2, 3, 1, 1),
            nn.BatchNorm2d(ch_2),
            nn.ReLU()
        )

    def forward(self, e_r, e_t, pre, rgb_global, t_global):
        cur_size = e_r.size()[2:]
        ch_2 = self.ch2

        g = self.gate(e_r, e_t)

        e_r = g[:, 0, :, :].unsqueeze(1).repeat(1, ch_2, 1, 1) * e_r
        e_t = g[:, 1, :, :].unsqueeze(1).repeat(1, ch_2, 1, 1) * e_t

        mask= self.spm(rgb_global, t_global)
        mask = F.interpolate(mask, cur_size, mode='bilinear', align_corners=True)
        e_r = mask * e_r
        e_t = (1 - mask) * e_t

        pre = self.ca1(pre)
        pre = self.conv_pre(F.interpolate(pre, cur_size, mode='bilinear', align_corners=True))

        fus = pre + e_r + e_t
        fus = pre + self.conv_fuse(fus)
        return fus


class GlobalInfo(nn.Module):  # ASPP

    def __init__(self):  # dim = 512*2  in_dim = 512  down_dim = 128
        super(GlobalInfo, self).__init__()

        self.conv1 = nn.Sequential(
            nn.Conv2d(512, 128, kernel_size=1), nn.BatchNorm2d(128), nn.PReLU()
        )
        self.conv2 = nn.Sequential(
            nn.Conv2d(512, 128, kernel_size=3, dilation=2, padding=2), nn.BatchNorm2d(128), nn.PReLU()
        )
        self.conv3 = nn.Sequential(
            nn.Conv2d(512, 128, kernel_size=3, dilation=4, padding=4), nn.BatchNorm2d(128), nn.PReLU()
        )
        self.conv4 = nn.Sequential(
            nn.Conv2d(512, 128, kernel_size=3, dilation=6, padding=6), nn.BatchNorm2d(128), nn.PReLU()
         )
        self.conv5 = nn.Sequential(
            nn.Conv2d(512, 128, kernel_size=1), nn.BatchNorm2d(128),  nn.PReLU()
        )
        self.fuse = nn.Sequential(
            nn.Conv2d(5 * 128, 512, kernel_size=1), nn.BatchNorm2d(512), nn.PReLU()
        )

    def forward(self, x):

        conv1 = self.conv1(x)
        conv2 = self.conv2(x)
        conv3 = self.conv3(x)
        conv4 = self.conv4(x)
        conv5 = F.upsample(self.conv5(F.adaptive_avg_pool2d(x, 1)), size=x.size()[2:], mode='bilinear')

        x_fuse = self.fuse(torch.cat((conv1, conv2, conv3, conv4, conv5), 1))

        return x_fuse


class CA(nn.Module):
    def __init__(self, in_ch):
        super(CA, self).__init__()
        self.avg_weight = nn.AdaptiveAvgPool2d(1)
        self.max_weight = nn.AdaptiveMaxPool2d(1)
        self.fus = nn.Sequential(
            nn.Conv2d(in_ch, in_ch // 2, 1, 1, 0),
            nn.ReLU(),
            nn.Conv2d(in_ch // 2, in_ch, 1, 1, 0),
        )
        self.c_mask = nn.Sigmoid()

    def forward(self, x):
        avg_map_c = self.avg_weight(x)
        max_map_c = self.max_weight(x)
        c_mask = self.c_mask(torch.add(self.fus(avg_map_c), self.fus(max_map_c)))
        return torch.mul(x, c_mask)


class SCAM(nn.Module):

    def __init__(self, in_ch):  # dim = 512*2  in_dim = 512  down_dim = 128
        super(SCAM, self).__init__()
        inter_ch = in_ch // 4

        self.r_conv1 = nn.Sequential(
            nn.Conv2d(in_ch, in_ch // 4, kernel_size=1), nn.BatchNorm2d(in_ch // 4), nn.PReLU()
        )
        self.r_conv2 = nn.Sequential(
            nn.Conv2d(in_ch, in_ch // 4, kernel_size=3, dilation=2, padding=2), nn.BatchNorm2d(in_ch // 4), nn.PReLU()
        )
        self.r_conv3 = nn.Sequential(
            nn.Conv2d(in_ch, in_ch // 4, kernel_size=3, dilation=4, padding=4), nn.BatchNorm2d(in_ch // 4), nn.PReLU()
        )

        self.t_conv1 = nn.Sequential(
            nn.Conv2d(in_ch, in_ch // 4, kernel_size=1), nn.BatchNorm2d(in_ch // 4), nn.PReLU()
        )
        self.t_conv2 = nn.Sequential(
            nn.Conv2d(in_ch, in_ch // 4, kernel_size=3, dilation=2, padding=2), nn.BatchNorm2d(in_ch // 4),
            nn.PReLU()
        )
        self.t_conv3 = nn.Sequential(
            nn.Conv2d(in_ch, in_ch // 4, kernel_size=3, dilation=4, padding=4), nn.BatchNorm2d(in_ch // 4),
            nn.PReLU()
        )

        self.r_fuse = nn.Conv2d(inter_ch * 3, 1, 3, 1, 1)
        self.t_fuse = nn.Conv2d(inter_ch * 3, 1, 3, 1, 1)
        self.fuse = nn.Conv2d(2, 1, 3, 1, 1)
        self.sig = nn.Sigmoid()

    def forward(self, rgb, t):

        r_conv1 = self.r_conv1(rgb)
        r_conv2 = self.r_conv2(rgb)
        r_conv3 = self.r_conv3(rgb)
        r_fuse = self.r_fuse(torch.cat((r_conv1, r_conv2, r_conv3), 1))

        t_conv1 = self.t_conv1(t)
        t_conv2 = self.t_conv2(t)
        t_conv3 = self.t_conv3(t)
        t_fuse = self.t_fuse(torch.cat((t_conv1, t_conv2, t_conv3), 1))

        fuse = torch.cat((r_fuse, t_fuse), 1)
        fuse = self.fuse(fuse)

        s_mask = self.sig(fuse)

        return s_mask


class Decoder(nn.Module):
    def __init__(self):
        super(Decoder, self).__init__()

        self.rgb_global = GlobalInfo()
        self.t_global = GlobalInfo()

        self.d5 = QM5(512, 512)
        self.d4 = QM(512, 512)
        self.d3 = QM(512, 256)
        self.d2 = QM(256, 128)
        self.d1 = QM(128, 64)

        self.score_1 = nn.Conv2d(64, 1, 1, 1, 0)
        self.score_2 = nn.Conv2d(128, 1, 1, 1, 0)
        self.score_3 = nn.Conv2d(256, 1, 1, 1, 0)
        self.score_4 = nn.Conv2d(512, 1, 1, 1, 0)
        self.score_5 = nn.Conv2d(512, 1, 1, 1, 0)

    def forward(self, rgb, t):
        xsize = rgb[0].size()[2:]
        rgb_global = self.rgb_global(rgb[4])
        t_global = self.t_global(t[4])
        global_info = rgb_global + t_global

        d5 = self.d5(rgb[4], t[4], global_info, rgb_global, t_global)
        d4 = self.d4(rgb[3], t[3], d5)
        d3 = self.d3(rgb[2], t[2], d4)
        d2 = self.d2(rgb[1], t[1], d3)
        d1 = self.d1(rgb[0], t[0], d2)

        score1 = self.score_1(d1)
        score2 = self.score_2(d2)
        score3 = self.score_3(d3)
        score4 = self.score_4(d4)
        score5 = self.score_5(d5)
        s1  = F.interpolate(score1, xsize, mode='bilinear', align_corners=True)
        s2  = F.interpolate(score2, xsize, mode='bilinear', align_corners=True)
        s3  = F.interpolate(score3, xsize, mode='bilinear', align_corners=True)
        score0 = s1 + s2 + s3

        return score1, score2, score3, score4, score5, score0


class MCAnet(nn.Module):
    def __init__(self, train=False):
        super(MCAnet, self).__init__()
        self.rgb_net = resnet50(pretrained=train)
        self.t_net = resnet50(pretrained=train)
        trans_layers_mapping = [[256, 128], [512, 256], [1024, 512], [2048, 512]]
        self.trans_rgb = nn.ModuleList()
        self.trans_t = nn.ModuleList()
        self.sigmoid = nn.Sigmoid()
        for mapp in trans_layers_mapping:
            self.trans_rgb.append(convblock(mapp[0], mapp[1], 1, 1, 0))
            self.trans_t.append(convblock(mapp[0], mapp[1], 1, 1, 0))
        self.decoder = Decoder()

        for m in chain(self.decoder.modules(), chain(self.trans_rgb.modules(), self.trans_t.modules())):
            if isinstance(m, nn.Conv2d):
                m.weight.data.normal_(0, 0.01)
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                m.bias.data.zero_()

    def forward(self, rgb, t):
        rgb_f = []
        t_f = []
        x = self.rgb_net.relu(self.rgb_net.bn1(self.rgb_net.conv1(rgb)))
        rgb_f.append(x)  # 64
        x = self.rgb_net.layer1(self.rgb_net.maxpool(x))
        rgb_f.append(self.trans_rgb[0](x))  # 256->128
        x = self.rgb_net.layer2(x)  # 256->512
        rgb_f.append(self.trans_rgb[1](x))  # 512->256
        x = self.rgb_net.layer3(x)  # 512->1024
        rgb_f.append(self.trans_rgb[2](x))  # 1024->512
        x = self.rgb_net.layer4(x)  # 1024->2048
        rgb_f.append(self.trans_rgb[3](x))  # 2048->512

        x = self.t_net.relu(self.t_net.bn1(self.t_net.conv1(t)))
        t_f.append(x)  # 64
        x = self.t_net.layer1(self.t_net.maxpool(x))
        t_f.append(self.trans_t[0](x))  # 256->128
        x = self.t_net.layer2(x)  # 256->512
        t_f.append(self.trans_t[1](x))  # 512->256
        x = self.t_net.layer3(x)  # 512->1024
        t_f.append(self.trans_t[2](x))  # 1024->512
        x = self.t_net.layer4(x)  # 1024->2048
        t_f.append(self.trans_t[3](x))  # 2048->512

        score1, score2, score3, score4, score5, score0 = self.decoder(rgb_f, t_f)
        return score1, score2, score3, score4, score5, socre0
